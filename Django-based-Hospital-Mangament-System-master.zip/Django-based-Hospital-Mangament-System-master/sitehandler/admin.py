from django.contrib import admin
from sitehandler.models import Doctor, Receptionist, Patient, Appointment
# Register your models here.
admin.site.register(Doctor)
admin.site.register(Receptionist)
admin.site.register(Patient)
admin.site.register(Appointment)
